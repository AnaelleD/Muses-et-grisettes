d3.csv("Data/bd_femmes_mtp.csv", function(error, data){	
	var liste_femmes =[];
	for (i = 0; i < data.length; i++) {
		liste_femmes.push(data[i]["nom"])
	}
	console.log(liste_femmes);
	

	["Les soeurs de l'évêque de Lodève Saint Fulcran","La belle Maguelonne","Marie de Montpellier","Jeanne de Sos",
​	"Madame Béatrix","Francèse de Cézelli","Elisabeth Bouissonnade","Madame de Sévigné","Madame Dunoyer","Anne-Marie-Louise d'Orléans",
	"Isabeau de Bonzi","Françoise de la Croix de Castries","Françoise de La Roche","Anne-Madelaine de Conty d'Argencourt",
	"Gabrielle de Gévaudan","Jeanne de Gévaudan"​,"Françoise de Bon","Judith de Saussure","Demoiselle Pagès","Marie Blayne",
	"Elisabeth Coste","Catherine Trillet","Jeanne-Marie Latour","Albine de Vassal","Madame Louis Figuier","Mère Saint-Philippe de Vacquier",
	"Virginie Montagnol","Soeur Chagny","Demoiselle Doumergue","Louise Guiraud","Vicomtesse Jeanne de Charrin","Marie Reynès-Monlaur",
	"Marie Giniez","Paule Minc","Lydie Wilson ","Augusta Barbet","Marie Joséphine Anne Fabrège","Camille Vialars","Maria del Pilar de San Menat",
​	"Marie Brondel de Roquevaire","Madame Hélène Tissié","Hélène de Savoie","Emma Calvé","Juliette Gréco","Simone Demangel",
​
45: "Laure Moulin"
​
46: "Sabine Zlatin"
​
47: "Marie-Antoinette Pallarès"
​
48: "Elise-Suzanne Tsitskichvili"
​
49: "Jeanne Atger"
​
50: "Jeanne Nizet"
​
51: "Emilienne Demougeot"
​
52: "Michèle Weil"
​
53: "Armande Le Pellec-Müller"
​
54: "Jeanne Galzy"
​
55: "Albertine Sarrazin"
​
56: "Madeleine Attal"
​
57: "Hélène Mandroux"

	function matchFemmes(input) {
	  var reg = new RegExp(input.split('').join('\\w*').replace(/\W/, ""), 'i');
	  return liste_femmes.filter(function(person) {
		if (person.match(reg)) {
		  return person;
		}
	  });
	}

	function changeInput(val) {
	  var autoCompleteResult = matchFemmes(val);
	  document.getElementById("#search_bar").innerHTML = autoCompleteResult;
	}
	
});